
 function refer(){
 swal("Referral", "Your username is your referral code, ask your friend to use it to register.", "success");
 }