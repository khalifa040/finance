$(document).ready(function() {
	
  
 $('#log').click(function() {
        window.location.assign('http://hausa.000.pe/login.html');  
 });
})