<?php
session_start();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
 <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<script src="jquery-3.6.1.js"></script>
<meta content="Free Money" name="keywords">
    <meta content="Free Money" name="description">
 <link rel="icon" type="image/x-icon" href="logo.png">
 <link rel="stylesheet" href="down.css">
  <style>
  img{ margin-left: auto;
   margin-right: auto;
   display: block;
}
}
</style>
    <title>Log out</title>
</head>
<body>
<br>
<br>
<img src="logout.png" width="90%" class="img">
</body>
</html>